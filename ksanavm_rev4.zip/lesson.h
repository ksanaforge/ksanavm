int lesson1(KsanaVm *vm);
int lesson2(KsanaVm *vm);
void addbasicword(KsanaVm *vm);
int lesson3(KsanaVm *vm);
void adddictword(KsanaVm *vm);
int lesson4(KsanaVm *vm);
int lesson5(KsanaVm *vm);
int lesson6(KsanaVm *vm);
int lesson6_loop(KsanaVm *vm); // for lesson 7 to reuse
int lesson7(KsanaVm *vm);
int lesson8(KsanaVm *vm);
