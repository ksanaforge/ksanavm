int lesson1(KsanaVm *vm);
int lesson2(KsanaVm *vm);
int lesson3(KsanaVm *vm);
int lesson4(KsanaVm *vm);
int lesson5(KsanaVm *vm);