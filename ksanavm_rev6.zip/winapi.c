#include "vm.h"
#include "windows.h"

// ( -dllname- )  create a new variable named dllname
void KVMLoadLib(KsanaVm *vm)
{
	int dll;
	KVMcreate(vm);
	dll=LoadLibraryA(vm->token);   // get the handle 
	DictCompile(vm,dll);                 
}


void KVMdoWinapi(KsanaVm *vm)
{
	int i,p,r, proc=*(int*)vm->ip;
	int paracount=*(int*)(vm->ip+CELLSIZE);

	for (i=0;i<paracount;i++)	{
		p=KVMPop(vm);
		_asm push p;
	}
	//invoke the function
	_asm call proc ; 
	//save function return value into variable r
	_asm	mov r,eax; 
	//push variable r to stack
	KVMPush(vm,r);
	//leave the high level defined by "CREATE" in Winapi
	KVMRet(vm);
}

// ( dll n -name- )
void KVMWinapi(KsanaVm *vm)
{
	int proc,paracount=KVMPop(vm);    
	int dll=KVMPop(vm);
	KVMcreate(vm);                                         // create a new word with same name

	proc=GetProcAddress(dll,vm->token);          // windows API
	
	ChangeCreateCodeField(vm,KVMdoWinapi);  // change code field
	DictCompile(vm,proc);                                // entry point of API
	DictCompile(vm,paracount);                        // number of parameter
}
//lesson 15
void KVMInclude(KsanaVm *vm)
{
	FILE *f;
	char *buffer[1024];
	KVMNextToken(vm);
	f=fopen(vm->token,"r");
	if (!f) {
		printf("error loading file %s",vm->token);
		return;
	}
	while (!feof(f)) {
		fgets(buffer,1024,f);
		Eval(vm,buffer);
	}
	fclose(f);
}

void addwinapiword(KsanaVm *vm)
{
	//lesson 9
	KVMAddWord(vm, "loadlibrary", KVMLoadLib);
	KVMAddWord(vm, "winapi", KVMWinapi);

	//lesson 15
	KVMAddWord(vm, "include", KVMInclude);
}