#include "vm.h"

void KVMDot(KsanaVm *vm)
{
	printf("%d ",KVMPop(vm));
}
void KVMCr(KsanaVm *vm)
{
	printf("\n");
}

void addioword(KsanaVm *vm)
{
	KVMAddWord(vm,".",KVMDot); 
	KVMAddWord(vm,"cr",KVMCr); 

}