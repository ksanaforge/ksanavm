#ifndef KVM_FLOW
#define  KVM_FLOW
#include "vm.h"

void addflowword(KsanaVm *vm);
#endif