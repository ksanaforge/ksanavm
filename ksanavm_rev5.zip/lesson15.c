/* lesson 15
  does>

yap 2007.1.21 release under GPL 3.0

  YOU WILL LEARN
  create allot does>
*/

#include "compiler.h"

int example15(KsanaVm *vm)
{
//defining the datastructure and behavior
	Eval(vm,": value create , does> r> @ ;");
//creating new instance
	Eval(vm,"8 value k");
//execute the instance
    Eval(vm,"k .");
}

int lesson15(KsanaVm *vm)
{	
	if (KVMFindWord(vm,"does>") ==0) {
		addword13(vm);
		example15(vm);
	}

	Eval(vm,vm->tib);
    KVMDumpStack(vm);
	return 0;
}