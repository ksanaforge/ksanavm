//main loop of Ksana Minimal Virtual Machine
//release under GPL 3.0
//yap 2007.12.20


#include "vm.h"
#include "lesson.h"

void main()
{
	char cmd [1024];            // buffer to hold input command
	KsanaVm *vm;               // the instance of virtual machine
	vm=KVMCreate();          // create the virtual machine

	memset(cmd,0,sizeof(cmd));

	puts("Tutorial of Ksana Minimal Virtual Machine");
	puts("http://tutor.ksana.tw");

	while (1) {

		printf("ok>");                    // the command prompt
		gets(cmd);                        // get the command from console
		KVMSetTib(vm,cmd);         // set it as Vm's terminal input buffer

		//lesson1(vm);
		//lesson2(vm);
		//lesson3(vm);
		//lesson4(vm);
		//lesson5(vm);                   // simply hit enter to start lesson5
		//lesson6(vm);
		//lesson7(vm);
		//lesson8(vm);

		lesson9(vm);
		//lesson10(vm);
		//lesson11(vm);
		//lesson12(vm);
		//lesson13(vm);
		//lesson14(vm);
		//lesson15(vm);
	
		if (vm->terminate) break;
	}

	KVMFree(vm);             // free the virtual machine
}