#include "compiler.h"

//lesson 11
void  KVMdoVariable(KsanaVm *vm)
{
	KVMPush(vm,vm->ip);
	KVMRet(vm);
}
// ( -name- )
void  KVMVariable(KsanaVm *vm)
{
	KVMNextToken(vm);
	strncpy(vm->newword.name,vm->token,sizeof(vm->newword));
	vm->newword.xt = vm->dictionary + vm->here;

	DictCompile(vm, KVMdoVariable);  // must add this for high level word
	DictCompile(vm,0);                      //initial value
	KVMAddWord(vm,vm->newword.name,vm->newword.xt);	
}

// ( v -- n )
void  KVMFetch(KsanaVm *vm)
{
	int *p, i=0;
	p=KVMPop(vm);
	if (p>=vm->dictionary && p<=vm->dictionary +vm->here) {
		i= *p;
		KVMPush (vm, i);
	} else {
		printf("invalid address 0x%x\n", p);
	}
}
// ( n v  --  )
void  KVMStore(KsanaVm *vm)
{
	int *p, i;
	p=KVMPop(vm);
	i=KVMPop(vm);
	if (p>=vm->dictionary && p<=vm->dictionary +vm->here) {
		*p=i;
	} else {
		printf("invalid address 0x%x\n", p);
	}
}

//lesson 12
void  KVMcreate(KsanaVm *vm)
{
	KVMNextToken(vm);
	strncpy(vm->newword.name,vm->token,sizeof(vm->newword));
	vm->newword.xt = vm->dictionary + vm->here;

	DictCompile(vm, KVMdoVariable);  // must add this for high level word
	KVMAddWord(vm,vm->newword.name,vm->newword.xt);	
}

void  KVMAllot(KsanaVm *vm)
{
	vm->here += KVMPop(vm);
}

void ChangeCreateCodeField(KsanaVm *vm,KVMXT xt)
{
	*(int*)vm->newword.xt = xt;
}
void  KVMDoes(KsanaVm *vm)
{
	int code=vm->ip;
	//change doCreate to code after does>
	ChangeCreateCodeField(vm,code);
	//stop here, code following does> are not executed.
	KVMRet(vm);
}

void KVMrfrom(KsanaVm *vm)
{
	KVMPush(vm,KVMRPop(vm));
}

void addvarword(KsanaVm *vm)
{
	//lesson 12
	KVMAddWord(vm,"variable",KVMVariable); 
	KVMAddWord(vm, "@", KVMFetch);
	KVMAddWord(vm, "!", KVMStore); 
	Eval(vm,": ? @ . ; ");

	//lesson 15
	KVMAddWord(vm, "create", KVMcreate); 
	Eval(vm, ": cells 4 * ;"); 
	KVMAddWord(vm, "allot", KVMAllot); 
	KVMAddWord(vm,"r>",KVMrfrom);	
	KVMAddWord(vm, "does>", KVMDoes); 

	
	
}
